import { Link, Outlet, useLocation } from 'react-router-dom';
import { Menu, Search, Video, Bell, Home, Upload, PlaySquare, Clock, ThumbsUp, Youtube } from 'lucide-react';
import { cn } from '@/utils/cn';
import { useState, useEffect } from 'react';

export function Layout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false); // Closed by default on mobile
  const [isMobile, setIsMobile] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Close sidebar on route change if mobile
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  }, [location, isMobile]);

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {/* Top Navigation Bar */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-900 h-14 flex items-center justify-between px-4 border-b border-zinc-800">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-zinc-800 rounded-full"
          >
            <Menu className="h-6 w-6 text-white" />
          </button>
          <Link to="/" className="flex items-center gap-1" title="Ax viral24 Home">
            <span className="font-bold text-2xl tracking-tighter text-white">Ax</span>
            <span className="font-bold text-2xl tracking-tighter bg-orange-500 text-black px-1 rounded-md">viral24</span>
          </Link>
        </div>

        <div className="hidden md:flex flex-1 max-w-2xl mx-4">
          <div className="flex w-full">
            <input 
              type="text" 
              placeholder="Search" 
              className="w-full bg-black border border-zinc-700 text-white rounded-l-md px-4 py-2 focus:border-orange-500 focus:outline-none"
            />
            <button className="bg-zinc-800 border border-l-0 border-zinc-700 rounded-r-md px-5 hover:bg-zinc-700">
              <Search className="h-5 w-5 text-zinc-400" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <Link to="/upload" className="p-2 hover:bg-zinc-800 rounded-full" title="Upload">
            <Video className="h-6 w-6 text-white" />
          </Link>
          <button className="p-2 hover:bg-zinc-800 rounded-full hidden sm:block">
            <Bell className="h-6 w-6 text-white" />
          </button>
          <div className="h-8 w-8 bg-orange-500 rounded-full flex items-center justify-center text-black font-bold cursor-pointer">
            A
          </div>
        </div>
      </header>

      <div className="flex pt-14">
        {/* Mobile Backdrop */}
        {isMobile && sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/80 z-30"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside 
          className={cn(
            "fixed left-0 top-14 bottom-0 bg-zinc-900 w-64 overflow-y-auto px-3 py-4 transition-transform duration-300 z-40 border-r border-zinc-800",
            !sidebarOpen && "-translate-x-full"
          )}
        >
          <div className="space-y-1 border-b border-zinc-800 pb-4 mb-4">
            <SidebarItem to="/" icon={Home} label="Home" active={isActive('/')} />
            <SidebarItem to="/shorts" icon={PlaySquare} label="Shorts" />
            <SidebarItem to="/subscriptions" icon={Youtube} label="Subscriptions" />
          </div>

          <div className="space-y-1 border-b border-zinc-800 pb-4 mb-4">
            <h3 className="px-3 py-2 text-base font-semibold text-zinc-400">You</h3>
            <SidebarItem to="/upload" icon={Upload} label="Your videos" active={isActive('/upload')} />
            <SidebarItem to="/history" icon={Clock} label="History" />
            <SidebarItem to="/liked" icon={ThumbsUp} label="Liked videos" />
          </div>
        </aside>

        {/* Main Content */}
        <main 
          className={cn(
            "flex-1 p-4 sm:p-6 transition-all duration-300 w-full",
            !isMobile && sidebarOpen ? "ml-64" : "ml-0"
          )}
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function SidebarItem({ to, icon: Icon, label, active = false }: { to: string, icon: any, label: string, active?: boolean }) {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center gap-5 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
        active 
          ? "bg-orange-500 text-black hover:bg-orange-600" 
          : "text-zinc-400 hover:bg-zinc-800 hover:text-white"
      )}
    >
      <Icon className={cn("h-6 w-6", active ? "fill-current" : "")} />
      <span className="truncate">{label}</span>
    </Link>
  );
}
