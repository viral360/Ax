import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload as UploadIcon, FileVideo, FileImage, Loader2 } from 'lucide-react';
import { db } from '@/lib/db';
import { cn } from '@/utils/cn';
import { generateThumbnail } from '@/lib/thumbnail';

export function Upload() {
  const navigate = useNavigate();
  const [pin, setPin] = useState('');
  const [authorized, setAuthorized] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      if (localStorage.getItem('upload_auth') === 'true') {
        setAuthorized(true);
      }
    } catch (e) {
      console.warn('LocalStorage access denied', e);
    }
  }, []);

  useEffect(() => {
    let isActive = true;
    if (file) {
      setThumbnailUrl(null); // Reset while generating
      generateThumbnail(file)
        .then((url) => {
          if (isActive) setThumbnailUrl(url);
        })
        .catch((e) => {
          if (isActive) console.warn('Failed to generate auto-thumbnail', e);
        });
    } else {
      setThumbnailUrl(null);
    }
    return () => { isActive = false; };
  }, [file]);

  const checkPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '@Pass1151') {
      setAuthorized(true);
      try {
        localStorage.setItem('upload_auth', 'true');
      } catch (e) {
        console.warn('LocalStorage access denied', e);
      }
    } else {
      setError('Incorrect PIN');
    }
  };

  if (!authorized) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="bg-zinc-900 p-8 rounded-lg shadow-md max-w-sm w-full border border-zinc-800">
          <h2 className="text-xl font-bold text-white mb-4 text-center">Admin Access</h2>
          <form onSubmit={checkPin} className="space-y-4">
            <div>
              <label htmlFor="pin" className="block text-sm font-medium text-zinc-400">Enter PIN to upload</label>
              <input
                type="password"
                id="pin"
                className="mt-1 block w-full rounded-md bg-black border-zinc-700 text-white shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm border p-2"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="PIN"
              />
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-bold text-black bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              Access
            </button>
          </form>
        </div>
      </div>
    );
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const validateAndSetFile = (file: File) => {
    setError(null);
    if (!file.type.startsWith('video/') && !file.type.startsWith('image/')) {
      setError('Please upload only video or image files.');
      return;
    }
    // Limit file size to 500MB for browser storage sanity
    if (file.size > 500 * 1024 * 1024) {
      setError('File is too large (max 500MB).');
      return;
    }
    setFile(file);
  };

  const handleCustomThumbnailChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const thumbFile = e.target.files[0];
      if (!thumbFile.type.startsWith('image/')) {
        setError('Thumbnail must be an image.');
        return;
      }
      try {
        const url = await generateThumbnail(thumbFile);
        setThumbnailUrl(url);
      } catch (err) {
        console.error('Failed to process custom thumbnail', err);
        setError('Failed to process custom thumbnail.');
      }
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setUploading(true);
    try {
      const type = file.type.startsWith('video/') ? 'video' : 'image';
      
      // Basic ID generation
      const id = Date.now().toString(36) + Math.random().toString(36).substr(2);

      await db.addMedia({
        id,
        title: file.name,
        type,
        mimeType: file.type,
        blob: file,
        thumbnail: thumbnailUrl || undefined,
        createdAt: Date.now(),
      });

      navigate('/');
    } catch (err: any) {
      console.error(err);
      if (err.name === 'QuotaExceededError') {
        setError('Storage full! Please delete some videos to free up space.');
      } else {
        setError('Failed to save file. Please try again.');
      }
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto py-6 sm:py-12 px-4 sm:px-6 lg:px-8">
      <div className="bg-zinc-900 rounded-lg shadow px-4 sm:px-6 py-6 border border-zinc-800">
        <div className="border-b border-zinc-800 pb-5 mb-5">
          <h3 className="text-lg leading-6 font-bold text-white">Upload Media</h3>
          <p className="mt-2 max-w-4xl text-sm text-zinc-400">
            Select a video or image to upload to your private gallery.
          </p>
        </div>

        {error && (
          <div className="mb-4 bg-red-900/20 border border-red-500/50 text-red-500 px-4 py-3 rounded relative" role="alert">
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div 
          className={cn(
            "relative border-2 border-dashed rounded-lg p-6 sm:p-12 text-center hover:bg-black transition-colors cursor-pointer",
            dragActive ? "border-orange-500 bg-zinc-800" : "border-zinc-700",
            file ? "border-green-500 bg-zinc-800" : ""
          )}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => !file && inputRef.current?.click()}
        >
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            accept="video/*,image/*"
            onChange={handleChange}
          />
          
          {file ? (
            <div className="flex flex-col items-center">
              {file.type.startsWith('video/') ? (
                <FileVideo className="h-12 w-12 text-green-500 mb-3" />
              ) : (
                <FileImage className="h-12 w-12 text-green-500 mb-3" />
              )}
              <span className="text-sm font-medium text-white">{file.name}</span>
              <span className="text-xs text-zinc-400 mt-1">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFile(null);
                  if (inputRef.current) inputRef.current.value = '';
                }}
                className="mt-4 inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-bold rounded text-black bg-orange-500 hover:bg-orange-600 focus:outline-none"
              >
                Remove
              </button>
            </div>
          ) : (
            <div className="space-y-1 text-center">
              <UploadIcon className="mx-auto h-12 w-12 text-zinc-500" />
              <div className="flex justify-center text-sm text-zinc-400">
                <span className="relative cursor-pointer rounded-md font-medium text-orange-500 hover:text-orange-400 focus-within:outline-none">
                  <span>Upload a file</span>
                </span>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-zinc-500">Video or Image up to 500MB</p>
            </div>
          )}
        </div>

        {file && (
          <div className="mt-6">
            <h4 className="text-sm font-medium text-white">Thumbnail</h4>
            <div className="mt-2 flex items-center space-x-4">
              <div className="h-24 w-40 bg-black rounded-md overflow-hidden border border-zinc-700 flex items-center justify-center">
                {thumbnailUrl ? (
                  <img src={thumbnailUrl} alt="Thumbnail preview" className="h-full w-full object-cover" />
                ) : (
                  <div className="text-xs text-zinc-500">Generating...</div>
                )}
              </div>
              <div className="flex-1">
                 <button
                  type="button"
                  onClick={() => thumbnailInputRef.current?.click()}
                  className="bg-black py-2 px-3 border border-zinc-700 rounded-md shadow-sm text-sm font-medium text-white hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                >
                  Change Thumbnail
                </button>
                <input
                  ref={thumbnailInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleCustomThumbnailChange}
                />
                <p className="mt-1 text-xs text-zinc-500">
                  Upload a custom image to use as the thumbnail.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="bg-black py-2 px-4 border border-zinc-700 rounded-md shadow-sm text-sm font-bold text-white hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 mr-3"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!file || uploading}
            onClick={handleUpload}
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-bold rounded-md text-black bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                Uploading...
              </>
            ) : (
              'Upload'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
