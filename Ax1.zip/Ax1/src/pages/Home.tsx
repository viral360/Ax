import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, Image as ImageIcon, MoreVertical, CheckCircle } from 'lucide-react';
import { db, MediaItem } from '@/lib/db';
import { cn } from '@/utils/cn';

export function Home() {
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const categories = ["All", "Gaming", "Music", "Live", "Mixes", "Computers", "Programming", "Podcasts", "News", "Sports", "Learning", "Fashion"];

  useEffect(() => {
    loadMedia();
  }, []);

  async function loadMedia() {
    try {
      const items = await db.getAllMedia();
      setMedia(items.sort((a, b) => b.createdAt - a.createdAt));
    } catch (error) {
      console.error('Failed to load media', error);
    } finally {
      setLoading(false);
    }
  }

  function formatTimeAgo(timestamp: number) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + (Math.floor(interval) === 1 ? " year ago" : " years ago");
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + (Math.floor(interval) === 1 ? " month ago" : " months ago");
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + (Math.floor(interval) === 1 ? " day ago" : " days ago");
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + (Math.floor(interval) === 1 ? " hour ago" : " hours ago");
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + (Math.floor(interval) === 1 ? " minute ago" : " minutes ago");
    return Math.floor(seconds) + (Math.floor(seconds) === 1 ? " second ago" : " seconds ago");
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-orange-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Categories */}
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4 sticky top-14 bg-black z-10 py-2">
        {categories.map((cat, i) => (
          <button
            key={cat}
            className={cn(
              "px-3 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition-colors",
              i === 0 
                ? "bg-orange-500 text-black" 
                : "bg-zinc-800 text-white hover:bg-zinc-700"
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {media.length === 0 ? (
        <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-4">
          <div className="bg-zinc-800 p-6 rounded-full">
            <ImageIcon className="h-12 w-12 text-orange-500" />
          </div>
          <h2 className="text-2xl font-semibold text-white">No content available</h2>
          <p className="text-zinc-400 max-w-sm">
            Start by uploading some videos or photos to fill up your stream.
          </p>
          <Link 
            to="/upload" 
            className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-black bg-orange-500 hover:bg-orange-600 focus:outline-none"
          >
            Upload Video
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-6 sm:gap-y-8">
          {media.map((item) => (
            <Link 
              key={item.id} 
              to={`/view/${item.id}`}
              className="group flex flex-col cursor-pointer"
            >
              {/* Thumbnail */}
              <div className="aspect-video bg-zinc-800 rounded-lg relative overflow-hidden mb-3 group-hover:rounded-none transition-all duration-200 border border-zinc-800 group-hover:border-orange-500">
                {item.thumbnail ? (
                  <div className="w-full h-full relative">
                    <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover" />
                    {item.type === 'video' && (
                      <>
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40 group-hover:bg-black/0 transition-colors">
                            <Play className="h-12 w-12 text-white opacity-80 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/80 px-1 py-0.5 rounded text-xs text-white font-bold">
                          12:34
                        </div>
                      </>
                    )}
                  </div>
                ) : (
                  item.type === 'video' ? (
                    <div className="w-full h-full flex items-center justify-center bg-black">
                       <Play className="h-12 w-12 text-white opacity-80" />
                       <div className="absolute bottom-2 right-2 bg-black/80 px-1 py-0.5 rounded text-xs text-white font-bold">
                         12:34
                       </div>
                    </div>
                  ) : (
                    <MediaPreview blob={item.blob} title={item.title} />
                  )
                )}
              </div>
              
              {/* Info */}
              <div className="flex gap-3 px-1">
                <div className="flex-shrink-0">
                  <div className="h-9 w-9 rounded-full bg-orange-500 flex items-center justify-center text-black font-bold text-sm">
                    C
                  </div>
                </div>
                <div className="flex flex-col flex-1 min-w-0">
                  <h3 className="text-base font-semibold text-white line-clamp-2 leading-tight group-hover:text-orange-500">
                    {item.title}
                  </h3>
                  <div className="mt-1 text-sm text-zinc-400 flex items-center">
                    <span>Cornhub Admin</span>
                    <CheckCircle className="h-3 w-3 ml-1 text-zinc-500 fill-black" />
                  </div>
                  <div className="text-sm text-zinc-400">
                    {Math.floor(Math.random() * 1000)}K views • {formatTimeAgo(item.createdAt)}
                  </div>
                </div>
                <button className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="h-5 w-5 text-zinc-400" />
                </button>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function MediaPreview({ blob, title }: { blob: Blob; title: string }) {
  const [src, setSrc] = useState<string>('');

  useEffect(() => {
    if (!blob || !(blob instanceof Blob)) return;
    try {
      const url = URL.createObjectURL(blob);
      setSrc(url);
      return () => URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to create object URL', e);
      setSrc(''); 
    }
  }, [blob]);

  if (!src) return <div className="w-full h-full bg-zinc-800 animate-pulse flex items-center justify-center text-xs text-zinc-600">No Preview</div>;

  return <img src={src} alt={title} className="w-full h-full object-cover transition-transform duration-300 hover:scale-105" />;
}
