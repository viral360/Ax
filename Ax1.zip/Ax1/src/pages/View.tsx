import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ThumbsUp, ThumbsDown, Share2, Download, MoreHorizontal, Bell, CheckCircle, Trash2, X } from 'lucide-react';
import { db, MediaItem } from '@/lib/db';
import { cn } from '@/utils/cn';

export function View() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [media, setMedia] = useState<MediaItem | null>(null);
  const [allMedia, setAllMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [src, setSrc] = useState<string | null>(null);
  const [subscribed, setSubscribed] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletePin, setDeletePin] = useState('');
  const [deleteError, setDeleteError] = useState('');

  const handleDelete = async () => {
    if (deletePin !== '@Pass1151') {
      setDeleteError('Incorrect PIN');
      return;
    }
    
    if (media) {
      try {
        await db.deleteMedia(media.id);
        navigate('/');
      } catch (e) {
        console.error('Failed to delete', e);
        setDeleteError('Failed to delete media');
      }
    }
  };

  useEffect(() => {
    if (id) {
      loadMedia(id);
    }
    loadAllMedia();
  }, [id]);

  useEffect(() => {
    if (media && media.blob && media.blob instanceof Blob) {
      try {
        const url = URL.createObjectURL(media.blob);
        setSrc(url);
        return () => URL.revokeObjectURL(url);
      } catch (e) {
        console.error('Failed to create media URL', e);
      }
    }
  }, [media]);

  async function loadAllMedia() {
    try {
      const items = await db.getAllMedia();
      setAllMedia(items.sort((a, b) => b.createdAt - a.createdAt));
    } catch (e) {
      console.error('Failed to load all media', e);
    }
  }

  async function loadMedia(id: string) {
    try {
      const item = await db.getMedia(id);
      if (item) {
        setMedia(item);
      } else {
        navigate('/');
      }
    } catch (error) {
      console.error('Failed to load media', error);
      navigate('/');
    } finally {
      setLoading(false);
    }
  }

  if (loading || !media || !src) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-orange-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 max-w-[1800px] mx-auto">
      {/* Main Content - Left */}
      <div className="flex-1 min-w-0">
        <div className="bg-black rounded-lg sm:rounded-xl overflow-hidden shadow-lg aspect-video flex items-center justify-center mb-4">
          {media.type === 'video' ? (
            <video 
              src={src} 
              controls 
              className="w-full h-full"
              autoPlay
            />
          ) : (
            <img 
              src={src} 
              alt={media.title} 
              className="max-w-full max-h-full object-contain"
            />
          )}
        </div>

        <h1 className="text-xl font-bold text-white line-clamp-2 mb-2">{media.title}</h1>
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-orange-500 flex items-center justify-center text-black font-bold">
              C
            </div>
            <div>
              <h3 className="font-semibold text-white flex items-center">
                Cornhub Admin
                <CheckCircle className="h-3 w-3 ml-1 text-zinc-500 fill-black" />
              </h3>
              <p className="text-xs text-zinc-400">1.2M subscribers</p>
            </div>
            <button 
              onClick={() => setSubscribed(!subscribed)}
              className={cn(
                "ml-4 px-4 py-2 rounded-full text-sm font-bold transition-colors",
                subscribed 
                  ? "bg-zinc-800 text-zinc-400 hover:bg-zinc-700" 
                  : "bg-orange-500 text-black hover:bg-orange-600"
              )}
            >
              {subscribed ? (
                <span className="flex items-center gap-2"><Bell className="h-4 w-4" /> Subscribed</span>
              ) : (
                "Subscribe"
              )}
            </button>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
            <div className="flex items-center bg-zinc-800 rounded-full">
              <button className="flex items-center gap-2 px-4 py-2 hover:bg-zinc-700 rounded-l-full border-r border-zinc-700 text-white">
                <ThumbsUp className="h-5 w-5" />
                <span className="text-sm font-medium">12K</span>
              </button>
              <button className="px-4 py-2 hover:bg-zinc-700 rounded-r-full text-white">
                <ThumbsDown className="h-5 w-5" />
              </button>
            </div>
            
            <button className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-full text-sm font-medium text-white">
              <Share2 className="h-5 w-5" />
              Share
            </button>
            
            <a 
              href={src} 
              download={media.title}
              className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-full text-sm font-medium text-white"
            >
              <Download className="h-5 w-5" />
              Download
            </a>

            <button 
              onClick={() => setShowDeleteConfirm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-red-900/50 text-red-500 hover:text-red-400 rounded-full text-sm font-medium transition-colors"
            >
              <Trash2 className="h-5 w-5" />
              Delete
            </button>
            
            <button className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded-full text-white">
              <MoreHorizontal className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="mt-4 bg-zinc-900 rounded-xl p-3 text-sm border border-zinc-800">
          <div className="font-semibold mb-1 text-white">
            {Math.floor(Math.random() * 500)}K views • {new Date(media.createdAt).toLocaleDateString()}
          </div>
          <p className="text-zinc-300">
            This is a private video uploaded to your personal stream. 
            Only you and those with the PIN can access this content.
          </p>
          <button className="mt-2 font-medium text-zinc-400 hover:text-white">Show more</button>
        </div>
        
        {/* Comments Section (Mock) */}
        <div className="mt-6">
          <h3 className="font-bold text-xl mb-4 text-white">Comments</h3>
          <div className="flex gap-4 mb-6">
            <div className="h-10 w-10 rounded-full bg-orange-600 flex items-center justify-center text-white font-bold shrink-0">
              Y
            </div>
            <div className="flex-1">
              <input 
                type="text" 
                placeholder="Add a comment..." 
                className="w-full bg-transparent border-b border-zinc-700 py-1 text-white focus:border-orange-500 focus:outline-none transition-colors placeholder-zinc-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Sidebar - Recommendations */}
      <div className="w-full lg:w-[400px] flex-shrink-0 space-y-3">
        {allMedia.filter(m => m.id !== media.id).map((item) => (
          <Link 
            key={item.id} 
            to={`/view/${item.id}`}
            className="flex gap-3 group cursor-pointer"
          >
            <div className="relative w-36 sm:w-40 flex-shrink-0 aspect-video bg-zinc-800 rounded-lg overflow-hidden border border-zinc-800 group-hover:border-orange-500 transition-colors">
              {item.thumbnail ? (
                <div className="w-full h-full relative group-hover:opacity-90 transition-opacity">
                  <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover" />
                  {item.type === 'video' && (
                    <div className="absolute bottom-1 right-1 bg-black/80 px-1 py-0.5 rounded text-[10px] text-white font-bold">
                       12:34
                    </div>
                  )}
                </div>
              ) : (
                 item.type === 'video' ? (
                    <div className="w-full h-full flex items-center justify-center bg-black">
                       <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center">
                          <div className="border-l-[10px] border-l-white border-y-[6px] border-y-transparent ml-1"></div>
                       </div>
                    </div>
                  ) : (
                    <MediaPreview blob={item.blob} title={item.title} />
                  )
              )}
            </div>
            <div className="flex flex-col min-w-0">
              <h4 className="font-semibold text-sm text-white line-clamp-2 leading-tight group-hover:text-orange-500">
                {item.title}
              </h4>
              <div className="text-xs text-zinc-400 mt-1">
                Cornhub Admin
              </div>
              <div className="text-xs text-zinc-500">
                {Math.floor(Math.random() * 100)}K views • 2 days ago
              </div>
            </div>
          </Link>
        ))}
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 rounded-xl shadow-xl w-full max-w-sm p-6 relative animate-in fade-in zoom-in duration-200 border border-zinc-800">
            <button 
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletePin('');
                setDeleteError('');
              }}
              className="absolute top-4 right-4 text-zinc-500 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            
            <h3 className="text-lg font-bold text-white mb-2">Delete Video?</h3>
            <p className="text-zinc-400 mb-4 text-sm">
              Enter admin PIN to confirm deletion. This action cannot be undone.
            </p>

            <input
              type="password"
              value={deletePin}
              onChange={(e) => {
                setDeletePin(e.target.value);
                setDeleteError('');
              }}
              placeholder="Enter PIN"
              className="w-full px-4 py-2 bg-black border border-zinc-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 mb-2"
              autoFocus
            />
            
            {deleteError && (
              <p className="text-red-500 text-sm mb-4">{deleteError}</p>
            )}

            <div className="flex justify-end gap-3 mt-4">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setDeletePin('');
                  setDeleteError('');
                }}
                className="px-4 py-2 text-zinc-400 hover:bg-zinc-800 rounded-lg font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold transition-colors shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MediaPreview({ blob, title }: { blob: Blob; title: string }) {
  const [src, setSrc] = useState<string>('');

  useEffect(() => {
    if (!blob || !(blob instanceof Blob)) return;
    try {
      const url = URL.createObjectURL(blob);
      setSrc(url);
      return () => URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to create object URL', e);
    }
  }, [blob]);

  if (!src) return <div className="w-full h-full bg-zinc-800 animate-pulse flex items-center justify-center text-xs text-zinc-600">No Preview</div>;

  return <img src={src} alt={title} className="w-full h-full object-cover" />;
}
