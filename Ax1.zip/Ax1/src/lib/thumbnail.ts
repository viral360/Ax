export function generateThumbnail(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const isVideo = file.type.startsWith('video/');
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      reject(new Error('Failed to get canvas context'));
      return;
    }

    if (isVideo) {
      const video = document.createElement('video');
      video.muted = true;
      video.playsInline = true;
      video.crossOrigin = 'anonymous';
      
      const timeoutId = setTimeout(() => {
        if (video.src) URL.revokeObjectURL(video.src);
        reject(new Error('Thumbnail generation timed out'));
      }, 5000); // 5 second timeout

      const cleanup = () => {
        clearTimeout(timeoutId);
        if (video.src) URL.revokeObjectURL(video.src);
      };

      video.onloadedmetadata = () => {
         if (video.duration === Infinity) {
             video.currentTime = 1;
         } else if (video.duration < 1) {
           video.currentTime = video.duration / 2;
         } else {
           video.currentTime = 1; 
         }
      };

      video.onseeked = () => {
        try {
          const maxWidth = 320;
          const scale = maxWidth / video.videoWidth;
          canvas.width = maxWidth;
          canvas.height = video.videoHeight * scale;

          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          
          cleanup();
          resolve(dataUrl);
        } catch (e) {
          cleanup();
          reject(e);
        }
      };

      video.onerror = () => {
        cleanup();
        reject(new Error('Error loading video'));
      };

      video.src = URL.createObjectURL(file);
      video.load();
    } else {
      const img = new Image();
      
      const timeoutId = setTimeout(() => {
         if (img.src) URL.revokeObjectURL(img.src);
         reject(new Error('Image load timed out'));
      }, 5000);

      const cleanup = () => {
        clearTimeout(timeoutId);
        if (img.src) URL.revokeObjectURL(img.src);
      };

      img.onload = () => {
        try {
          const maxSize = 320;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > maxSize) {
              height *= maxSize / width;
              width = maxSize;
            }
          } else {
            if (height > maxSize) {
              width *= maxSize / height;
              height = maxSize;
            }
          }

          canvas.width = width;
          canvas.height = height;

          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          
          cleanup();
          resolve(dataUrl);
        } catch (e) {
          cleanup();
          reject(e);
        }
      };

      img.onerror = () => {
        cleanup();
        reject(new Error('Error loading image'));
      };

      img.src = URL.createObjectURL(file);
    }
  });
}
