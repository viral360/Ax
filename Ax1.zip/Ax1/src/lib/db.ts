import { openDB, DBSchema } from 'idb';

export interface MediaItem {
  id: string;
  title: string;
  type: 'video' | 'image';
  mimeType: string;
  blob: Blob;
  thumbnail?: string;
  createdAt: number;
}

interface MyDB extends DBSchema {
  media: {
    key: string;
    value: MediaItem;
    indexes: { 'by-date': number };
  };
}

const dbPromise = openDB<MyDB>('my-stream-db', 1, {
  upgrade(db) {
    const store = db.createObjectStore('media', { keyPath: 'id' });
    store.createIndex('by-date', 'createdAt');
  },
}).catch(err => {
  console.error('Failed to open database:', err);
  throw err;
});

export const db = {
  async addMedia(item: MediaItem) {
    try {
      const db = await dbPromise;
      return await db.put('media', item);
    } catch (e) {
      console.error('Error adding media:', e);
      throw e;
    }
  },
  async getAllMedia() {
    try {
      const db = await dbPromise;
      return await db.getAllFromIndex('media', 'by-date');
    } catch (e) {
      console.error('Error getting all media:', e);
      return []; // Return empty array on error to prevent UI crashes
    }
  },
  async getMedia(id: string) {
    try {
      const db = await dbPromise;
      return await db.get('media', id);
    } catch (e) {
      console.error('Error getting media:', e);
      return undefined;
    }
  },
  async deleteMedia(id: string) {
    try {
      const db = await dbPromise;
      return await db.delete('media', id);
    } catch (e) {
      console.error('Error deleting media:', e);
      throw e;
    }
  },
};
